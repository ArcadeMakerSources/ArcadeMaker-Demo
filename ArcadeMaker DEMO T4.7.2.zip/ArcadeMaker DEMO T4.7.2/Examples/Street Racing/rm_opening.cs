namespace Game
{
    public partial class rm_opening
    {
        protected override void Create()
        {
            
        }
    }
}