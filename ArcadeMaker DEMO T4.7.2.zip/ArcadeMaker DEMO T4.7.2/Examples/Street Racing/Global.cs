namespace Game
{
    public static class Global
    {
        public static int score = 0;
        public static int lives = 3;
        public static int petrol = 100;
        
    }
}