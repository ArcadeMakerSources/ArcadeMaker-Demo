namespace Game
{
    public partial class rm_game
    {
        protected override void Create()
        {
            
        }
    }
}