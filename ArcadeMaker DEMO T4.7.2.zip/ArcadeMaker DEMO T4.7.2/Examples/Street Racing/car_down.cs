using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ArcadeMaker;
using ArcadeMaker.Components;
using ArcadeMaker.Controls;
using ArcadeMaker.Drawing;
using ArcadeMaker.GameItems;
using ArcadeMaker.Models;
using ArcadeMaker.Runtime;
using ArcadeMaker.Properties;

namespace Game
{
   public partial class car_down
   {
      public bool dead = false;
      
      protected override void Create()
      {
         Random random = new Random();
         imageIndex = random.Next(4);
         imageSpeed = 0;
         x = 44 + 120;
         y = -80;
         vspeed = 6;
         if (random.Next(2) == 0)
         {
            x = 44 + 60;
            y = -80;
            vspeed = 5;
            if (random.Next(3) == 0)
            {
               x = 44;
               y = -80;
               vspeed = 4;
            }
         }
         if (PlaceMeeting<car_down>(x, y))
            InstanceDestroy();   
      }
      
      protected override void Step()
      {
         if (PlaceMeeting<car_down>(x, y) || PlaceMeeting<car_racing>(x, y) || PlaceMeeting<police>(x, y))
         {
            if (dead)
               return;
            Sounds.collision.Play(false);
            sprite = Sprites.sprite_car_down_dead;
            vspeed = 3;
            dead = true;
         }
         
         if (OutsideRoom())
         {
            if (y > room.height)
               InstanceDestroy();
         }
      }
      
      protected override void Draw()
      {
         
      }
      
      protected override void KeyDown(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyUp(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyPress(KeyboardEventArgs e)
      {
         
      }
      
      protected override void MouseDown(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MousePress(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseUp(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseWheel(MouseWheelEventArgs e)
      {

      }

      protected override void Alarm(int alarm)
      {

      }
   }
}