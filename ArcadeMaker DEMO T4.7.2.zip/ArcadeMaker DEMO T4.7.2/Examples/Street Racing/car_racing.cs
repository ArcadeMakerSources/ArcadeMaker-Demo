using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ArcadeMaker;
using ArcadeMaker.Components;
using ArcadeMaker.Controls;
using ArcadeMaker.Drawing;
using ArcadeMaker.GameItems;
using ArcadeMaker.Models;
using ArcadeMaker.Runtime;
using ArcadeMaker.Properties;

namespace Game
{
   public partial class car_racing
   {
      public bool dead = false;
      
      protected override void Create()
      {
         vspeed = 0;
      }
      
      protected override void Step()
      {
         if (!dead)
         {
            if (Global.petrol <= 0)
            {
               vspeed = 3;
               Global.petrol = -1;
            }
            Global.petrol--;
         }
         
         if (PlaceMeeting<car_down>(x, y))
         {
            if (!dead)
            {
                Sounds.collision.Play(false);
                sprite = Sprites.sprite_racing_dead;
                vspeed = 3;
                dead = true;
            }
         }
         
         if (PlaceMeeting<car_up>(x, y))
         {
            if (!dead)
            {
                Sounds.collision.Play(false);
                sprite = Sprites.sprite_racing_dead;
                vspeed = 3;
                dead = true;
            }
         }
         
         gas otherGas = InstanceMeeting<gas>(x, y);
         if (otherGas != null)
         {
            if (!dead)
            {
                Sounds.gas_sound.Play(false);
                Global.petrol = Math.Min(1000, Global.petrol + 400);
                otherGas.InstanceDestroy();
            }
         }
         
         if (PlaceMeeting<police>(x, y))
         {
            if (dead)
            {
                Sounds.collision.Play(false);
                sprite = Sprites.sprite_racing_dead;
                vspeed = 3;
                dead = true;
            }
         }
         

         if (y > room.height)
         {
            Global.lives--;
            Sounds.sirens.Stop();
            room.GoTo(room);
         }
      }
      
      protected override void Draw()
      {
         
      }
      
      protected override void KeyDown(KeyboardEventArgs e)
      {
         if (e.Key == VKey.Left)
         {
            if (Global.petrol > 0 && x > 32 && !dead)
               x -= 2;
         }
         if (e.Key == VKey.Up)
         {
            if (Global.petrol > 0 && !dead)
               y -= 3;
         }
         if (e.Key == VKey.Right)
         {
            if (Global.petrol > 0 && x < 360 && !dead)
               x += 2;
         }
         if (e.Key == VKey.Down)
         {
            if (Global.petrol > 0 && !dead)
               y += 3;
         }
      }
      
      protected override void KeyUp(KeyboardEventArgs e)
      {
         if (e.Key == VKey.Space)
            Sounds.horn.Stop();
      }
      
      protected override void KeyPress(KeyboardEventArgs e)
      {
         if (e.Key == VKey.Space)
            Sounds.horn.Play(true);
      }
      
      protected override void MouseDown(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MousePress(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseUp(MouseButtonEventArgs e)
      {
          
      }

      protected override void MouseWheel(MouseWheelEventArgs e)
      {

      }

      protected override void Alarm(int alarm)
      {

      }
   }
}