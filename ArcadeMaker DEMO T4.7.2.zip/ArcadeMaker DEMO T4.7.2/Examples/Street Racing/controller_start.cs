using ArcadeMaker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using ArcadeMaker.Components;
using ArcadeMaker.Controls;
using ArcadeMaker.Drawing;
using ArcadeMaker.GameItems;
using ArcadeMaker.Models;
using ArcadeMaker.Runtime;
using ArcadeMaker.Properties;

namespace Game
{
   public partial class controller_start
   {
      Random random = new Random();
      protected override void Create()
      {
         Global.score = 0;
         Global.lives = 3;
         
         Sounds.background_music.Play(true);
      }
      
      protected override void Step()
      {
         // Create Cars
         if (random.Next(49) == 0)
            room.InsertInstance(new car_down(0, 0));
         if (random.Next(99) == 0)
            room.InsertInstance(new car_up(0, 0));
      }
      
      protected override void Draw()
      {
         font = Fonts.font_large;
         color = Color.Red;
         DrawText(200, 40, "Street Racing");
         font = Fonts.font_small;
         color = Color.Yellow;
         DrawText(200, 100, "Press any key to start");
         DrawText(200, 130, "Press escape to quit");
      }
      
      protected override void KeyDown(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyUp(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyPress(KeyboardEventArgs e)
      {
         room.GoToNext();
      }
      
      protected override void MouseDown(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MousePress(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseUp(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseWheel(MouseWheelEventArgs e)
      {

      }

      protected override void Alarm(int alarm)
      {

      }
   }
}