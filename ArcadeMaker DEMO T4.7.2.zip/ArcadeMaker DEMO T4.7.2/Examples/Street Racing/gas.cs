using ArcadeMaker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ArcadeMaker.Components;
using ArcadeMaker.Controls;
using ArcadeMaker.Drawing;
using ArcadeMaker.GameItems;
using ArcadeMaker.Models;
using ArcadeMaker.Runtime;
using ArcadeMaker.Properties;

namespace Game
{
   public partial class gas
   {
      protected override void Create()
      {
         vspeed = 3;
      }
      
      protected override void Step()
      {
         if (OutsideRoom())
         {
            if (y > room.height)
               InstanceDestroy();
         }
      }
      
      protected override void Draw()
      {
         
      }
      
      protected override void KeyDown(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyUp(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyPress(KeyboardEventArgs e)
      {
         
      }
      
      protected override void MouseDown(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MousePress(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseUp(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseWheel(MouseWheelEventArgs e)
      {

      }

      protected override void Alarm(int alarm)
      {

      }
   }
}