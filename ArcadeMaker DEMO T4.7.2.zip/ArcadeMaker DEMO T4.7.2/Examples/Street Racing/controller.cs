using ArcadeMaker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using ArcadeMaker.Components;
using ArcadeMaker.Controls;
using ArcadeMaker.Drawing;
using ArcadeMaker.GameItems;
using ArcadeMaker.Models;
using ArcadeMaker.Runtime;
using ArcadeMaker.Properties;

namespace Game
{
   public partial class controller
   {
      Random random = new Random();
      protected override void Create()
      {
         Global.petrol = 1000;
         alarm[0] = 300;
      }
      
      protected override void Step()
      {
         Global.score++;
         // Create Cars
         if ((int)(random.NextDouble()*(70 - Global.score / 200d)) == 0)
            room.InsertInstance(new car_down(0, 0));
         if ((int)(random.NextDouble()*(200 - Global.score / 200d)) == 0)
            room.InsertInstance(new car_up(0, 0));
         if (Global.score > 2000)
            if ((int)(random.NextDouble()*(800-Global.score/30d)) == 0)
               if (!police.Exists())
                  room.InsertInstance(new police(0, 0));
         if (Global.lives < 1)
         {
            GamePlay.Pause();
            MessageBox.Show("Game Over");
            RestartGame();
         }
      }
      
      protected override void Draw()
      {
         color = Color.White;
         font = Fonts.font_small;
         DrawText(420, 20, "Score: " + Global.score);
         DrawText(420, 50, "Cars left: " + Global.lives);
         DrawText(420, 100, "Petrol: ");
         // draw the petrol left box
         color = Color.Black;
         DrawRect(480, 100, 580, 120, false);
         color = Color.Red;
         if (Global.petrol > 300)
            color = Color.Yellow;
         if (Global.petrol > 700)
            color = Color.Green;
         DrawRect(480, 100, 480 + Math.Max(0,Math.Min(100,Global.petrol/10)), 120, false);
      }
      
      protected override void KeyDown(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyUp(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyPress(KeyboardEventArgs e)
      {
         
      }
      
      protected override void MouseDown(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MousePress(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseUp(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseWheel(MouseWheelEventArgs e)
      {

      }

      protected override void Alarm(int alarm)
      {
         if (alarm == 0)
         {
            room.InsertInstance(new gas(40 + random.Next(320), -40));
            base.alarm[0] = 300 + Global.score / 100;
         }
      }
   }
}