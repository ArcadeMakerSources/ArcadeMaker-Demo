using ArcadeMaker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using ArcadeMaker.Components;
using ArcadeMaker.Controls;
using ArcadeMaker.Drawing;
using ArcadeMaker.GameItems;
using ArcadeMaker.Models;
using ArcadeMaker.Runtime;
using ArcadeMaker.Properties;

namespace Game
{
   public partial class police
   {
      public bool dead = false;
      
      protected override void Create()
      {
         Sounds.sirens.Play(true);
         vspeed = -1;
         x = car_racing.instances[0].x;
         y = room.height;
         // Destroy yourself if you hit something
         if (PlaceMeeting<car_racing>(x, y) || PlaceMeeting<car_up>(x, y) || PlaceMeeting<car_down>(x, y))
         {
            InstanceDestroy();
            Sounds.sirens.Stop();
         }
      }
      
      protected override void Step()
      {
         if (dead)
            return;
         if (car_racing.instances[0].x<x && !PlaceMeeting<ObjectModel>(x-8,y))
         {
            x -= 2;
         }
         if (car_racing.instances[0].x>x && !PlaceMeeting<ObjectModel>(x+8,y))
         {
            x += 2;
         }
         if (PlaceMeeting<car_down>(x, y) || PlaceMeeting<car_racing>(x, y) || PlaceMeeting<car_up>(x, y) || PlaceMeeting<police>(x, y))
         {
            if (dead)
               return;
            Sounds.collision.Play(false);
            sprite = Sprites.sprite_car_down_dead;
            imageSpeed = 0;
            vspeed = 3;
            dead = true;
         }
         if (OutsideRoom())
         {
            if (y<0 || y > room.height+20)
               InstanceDestroy();
         }
      }
      
      protected override void Draw()
      {
         
      }
      
      protected override void KeyDown(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyUp(KeyboardEventArgs e)
      {
         
      }
      
      protected override void KeyPress(KeyboardEventArgs e)
      {
         
      }
      
      protected override void MouseDown(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MousePress(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseUp(MouseButtonEventArgs e)
      {
          
      }
      
      protected override void MouseWheel(MouseWheelEventArgs e)
      {

      }

      protected override void Alarm(int alarm)
      {

      }
   }
}